﻿namespace p08_MilitaryElite.Interfaces
{
    public interface IRepair
    {
        string PartName { get; }

        int HourWorked { get; }
    }
}