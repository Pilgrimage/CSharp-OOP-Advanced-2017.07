﻿namespace p08_MilitaryElite.Interfaces
{
    public interface IPrivate : ISoldier
    {
        double Salary { get; }
    }
}