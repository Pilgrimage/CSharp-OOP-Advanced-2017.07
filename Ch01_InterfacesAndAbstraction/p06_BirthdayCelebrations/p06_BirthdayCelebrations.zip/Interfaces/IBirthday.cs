﻿namespace p06_BirthdayCelebrations
{
    public interface IBirthday
    {
        string BirthDate { get; }
    }
}