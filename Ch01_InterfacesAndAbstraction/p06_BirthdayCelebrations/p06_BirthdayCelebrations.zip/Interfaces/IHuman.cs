﻿namespace p06_BirthdayCelebrations
{
    public interface IHuman
    {
        string Name { get; }
        int Age { get; }
    }
}