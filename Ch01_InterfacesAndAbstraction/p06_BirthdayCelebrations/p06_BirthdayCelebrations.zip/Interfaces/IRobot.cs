﻿namespace p06_BirthdayCelebrations
{
    public interface IRobot
    {
        string Model { get; }
    }
}