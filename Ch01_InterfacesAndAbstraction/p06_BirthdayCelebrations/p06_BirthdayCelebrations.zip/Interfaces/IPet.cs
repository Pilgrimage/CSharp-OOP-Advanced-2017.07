﻿namespace p06_BirthdayCelebrations
{
    public interface IPet
    {
        string Name { get; }
    }
}