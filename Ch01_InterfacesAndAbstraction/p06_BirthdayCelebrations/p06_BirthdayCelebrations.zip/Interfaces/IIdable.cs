﻿namespace p06_BirthdayCelebrations
{
    public interface IIdable
    {
        string Id { get; }
    }
}