﻿namespace p01_DefineAnInterfaceIPerson.Models
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}