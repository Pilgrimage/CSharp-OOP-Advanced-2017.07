﻿namespace p09_CollectionHierarchy
{
    public interface IAddCollection<T>
    {
        int Add(T element);
    }
}
