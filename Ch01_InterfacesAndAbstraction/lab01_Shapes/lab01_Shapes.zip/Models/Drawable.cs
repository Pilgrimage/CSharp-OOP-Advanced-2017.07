﻿interface IDrawable
{
    void Draw();
}

