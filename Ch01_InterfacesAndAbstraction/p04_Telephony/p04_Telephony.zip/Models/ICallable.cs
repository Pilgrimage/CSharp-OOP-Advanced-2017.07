﻿namespace p04_Telephony.Models
{
    public interface ICallable
    {
        string Call(string callNumber);
    }
}