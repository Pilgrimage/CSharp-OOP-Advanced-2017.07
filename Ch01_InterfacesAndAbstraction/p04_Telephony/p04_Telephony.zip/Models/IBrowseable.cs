﻿namespace p04_Telephony.Models
{
    public interface IBrowseable
    {
        string Browse(string urlAddress);
    }
}