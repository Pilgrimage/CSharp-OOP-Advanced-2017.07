﻿namespace p07_FoodShortage
{
    public interface IPet
    {
        string Name { get; }
    }
}