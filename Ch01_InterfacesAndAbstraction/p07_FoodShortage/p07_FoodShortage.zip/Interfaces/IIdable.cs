﻿namespace p07_FoodShortage
{
    public interface IIdable
    {
        string Id { get; }
    }
}