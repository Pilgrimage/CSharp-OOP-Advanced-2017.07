﻿namespace p07_FoodShortage
{
    public interface IBirthday
    {
        string BirthDate { get; }
    }
}