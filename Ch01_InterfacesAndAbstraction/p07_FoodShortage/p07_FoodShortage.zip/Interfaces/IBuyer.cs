﻿namespace p07_FoodShortage
{
    public interface IBuyer
    {
        int Food { get; }

        void BuyFood();
    }
}