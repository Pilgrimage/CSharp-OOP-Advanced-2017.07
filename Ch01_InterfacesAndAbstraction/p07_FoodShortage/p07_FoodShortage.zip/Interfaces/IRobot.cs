﻿namespace p07_FoodShortage
{
    public interface IRobot
    {
        string Model { get; }
    }
}