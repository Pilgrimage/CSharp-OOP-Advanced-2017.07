﻿namespace p10_CreateCustomClassAttribute.Models
{
    using Attributes;

    [CustomClass("Pesho", 3, "Used for C# OOP Advanced Course - Enumerations and Attributes.", "Pesho", "Svetlio")]
    public class Weapon
    {
        
    }
}