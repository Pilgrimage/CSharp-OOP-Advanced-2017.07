﻿namespace p09_TrafficLights.Enums
{
    public enum LightColor
    {
        Red,
        Green,
        Yellow
    }
}