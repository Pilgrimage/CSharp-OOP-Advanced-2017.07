﻿namespace p01_CardSuit.Enums
{
    public enum Suit
    {
       Clubs,
       Diamonds,
       Hearts,
       Spades
    }
}