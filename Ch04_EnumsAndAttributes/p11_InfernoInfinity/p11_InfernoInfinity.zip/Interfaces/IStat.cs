﻿namespace p11_InfernoInfinity.Interfaces
{
    public interface IStat
    {
        int Strength { get; set; }
        int Agility { get; set; }
        int Vitality { get; set; }
    }
}