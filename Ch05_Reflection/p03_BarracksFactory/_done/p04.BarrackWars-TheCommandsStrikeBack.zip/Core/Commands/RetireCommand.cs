﻿namespace p03_BarracksFactory.Core.Commands
{
    using System;
    using Contracts;

    public class RetireCommand : Command
    {
        public RetireCommand(string[] data, IRepository repository, IUnitFactory unitFactory) : base(data, repository, unitFactory)
        {
        }

        public override string Execute()
        {
            this.Repository.RemoveUnit(Data[1]);
            return $"{Data[1]} retired!";
        }
    }
}