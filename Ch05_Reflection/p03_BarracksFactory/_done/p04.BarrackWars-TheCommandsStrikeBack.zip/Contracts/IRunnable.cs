﻿namespace p03_BarracksFactory.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
