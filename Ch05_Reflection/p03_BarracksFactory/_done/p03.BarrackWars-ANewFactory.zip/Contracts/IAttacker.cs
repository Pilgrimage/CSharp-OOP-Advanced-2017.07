﻿namespace p03_BarracksFactory.Contracts
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}
