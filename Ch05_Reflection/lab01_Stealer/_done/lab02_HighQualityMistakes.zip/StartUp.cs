﻿using System;

public class StartUp
{
    public static void Main()
    {
        Spy spy = new Spy();

        // lab01_Stealer
        //string result = spy.StealFieldInfo("Hacker", "username", "password");

        // lab02_HighQualityMistakes
        string result = spy.AnalyzeAcessModifiers("Hacker");

        Console.WriteLine(result);
    }
}

