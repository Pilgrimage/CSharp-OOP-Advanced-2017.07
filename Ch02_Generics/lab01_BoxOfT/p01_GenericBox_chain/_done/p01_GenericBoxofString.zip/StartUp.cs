﻿using System;

namespace p01_GenericBox_chain
{
    public class StartUp
    {
        public static void Main()
        {
            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                Box<string> boxStr = new Box<string>(Console.ReadLine());
                Console.WriteLine(boxStr);
            }

        }
    }
}
