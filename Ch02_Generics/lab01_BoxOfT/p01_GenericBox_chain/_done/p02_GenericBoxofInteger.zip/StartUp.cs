﻿using System;

namespace p01_GenericBox_chain
{
    public class StartUp
    {
        public static void Main()
        {
            int count = int.Parse(Console.ReadLine());

            //// Problem 02.Generic Box of String
            //for (int i = 0; i < count; i++)
            //{
            //    Box<string> boxStr = new Box<string>(Console.ReadLine());
            //    Console.WriteLine(boxStr);
            //}

            // Problem 02.Generic Box of Integer
            for (int i = 0; i < count; i++)
            {
                Box<int> boxStr = new Box<int>(int.Parse(Console.ReadLine()));
                Console.WriteLine(boxStr);
            }


        }
    }
}
