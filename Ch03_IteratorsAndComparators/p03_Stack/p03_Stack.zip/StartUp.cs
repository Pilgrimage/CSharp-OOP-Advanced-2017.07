﻿namespace p03_Stack
{
    public class StartUp
    {
        public static void Main()
        {
            // Based on state solution

            Engine engine = new Engine();
            engine.Run();
        }
    }
}
